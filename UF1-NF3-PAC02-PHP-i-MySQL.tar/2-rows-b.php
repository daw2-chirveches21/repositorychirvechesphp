<?php
$db = mysqli_connect(gethostname(), 'root', 'root') or 
    die ('Unable to connect. Check your connection parameters.');
mysqli_select_db($db,'moviesite') or die(mysqli_error($db));


$query = 'INSERT INTO movie
        (movie_id, movie_name, movie_type, movie_year, movie_leadactor,
        movie_director)
    VALUES
        (10, "Valerian and the City of a Thousand Planets", 1, 2017, 1, 2),
        (11, "Blade Runner 2049", 1, 2017, 5, 6),
        (12, "Godzilla: King of Monsters", 1, 2019, 4, 3)';

$result = mysqli_query($db,$query) or die(mysqli_error($db));

$query  = 'INSERT INTO people
        (people_id, people_fullname, people_isactor, people_isdirector)
    VALUES
        (10, "Dane DeHaan", 1, 0),
        (11, "Luc Besson", 0, 1),
        (12, "Michael Dougherty", 0, 1),
        (13, "Millie Bobby Brown", 1, 0),
        (14, "Ryan Gosling", 1, 0),
        (15, "Denis Villeneuve", 0, 1)';
mysqli_query($db,$query) or die(mysqli_error($db));


echo 'Se ha ejecutado correctamente';
?>