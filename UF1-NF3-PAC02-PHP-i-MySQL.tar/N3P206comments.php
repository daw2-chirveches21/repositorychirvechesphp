<!DOCTYPE html>
<html>
<head>
<title>PHP</title>
</head>
<body>
<h3>Lista</h3>


	<ol>
		<li>Que es el $_SESSION</li>
		<li>Que es el $_GET</li>
		<li>Que es el $_COOKIE</li>
		<li>Que es el $_POST</li>
		<li>Como hacer un type checkbox</li>
		<li>Saber a como guardar un estilo en una cookie</li>
		<li>Saber utilizar los if</li>
		<li>Saber a como poner un type que muestre para elegir colores</li>
		<li>Saber utilizar setcookie</li>
		<li>Saber manejar mejor el codenvy</li>
	</ol>

<h3>Calificacion</h3>
<p>
	El documento le pondria un 7 el problema que veo es que esta todo en ingles y tardas a enter a que se refiere o a no saber.
</p>
<h3>Definirme</h3>
<p>
	Soy un estudiante al que le apasiona aprender en el mundo de la programacion aunque le cueste un poco al inicio de cada nuevo ejercicio pero suele solucionarlo si se concentra.
</p>
<h3>Mejora</h3>
<p>
	No mejoraria nada.
</p>
</body>
</html>